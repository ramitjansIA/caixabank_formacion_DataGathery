"""Componentes reutilizables para presentaciones corporativas (python-pptx)."""
from pptx import Presentation
from pptx.util import Inches, Pt
from pptx.dml.color import RGBColor
from pptx.enum.text import PP_ALIGN, MSO_ANCHOR
from pptx.enum.shapes import MSO_SHAPE

COLORS = {'navy':'14243B','blue':'2764D8','cyan':'17B8A6','white':'FFFFFF','muted':'65758A','pale':'EFF4FA','orange':'F3A43B'}
def rgb(code): return RGBColor.from_string(code)
def make_presentation():
    p=Presentation(); p.slide_width=Inches(13.333); p.slide_height=Inches(7.5); return p

def rect(slide,x,y,w,h,color,rounding=False):
    shape=slide.shapes.add_shape(MSO_SHAPE.ROUNDED_RECTANGLE if rounding else MSO_SHAPE.RECTANGLE, Inches(x), Inches(y), Inches(w), Inches(h))
    shape.fill.solid(); shape.fill.fore_color.rgb=rgb(color); shape.line.fill.background(); return shape

def text(slide,content,x,y,w,h,size=18,color='14243B',bold=False,align=None):
    box=slide.shapes.add_textbox(Inches(x), Inches(y), Inches(w), Inches(h))
    tf=box.text_frame; tf.word_wrap=True; tf.margin_left=Pt(0); tf.margin_right=Pt(0)
    for i,line in enumerate(str(content).split('\n')):
        p=tf.paragraphs[0] if i==0 else tf.add_paragraph()
        p.text=line; p.font.name='Aptos'; p.font.size=Pt(size); p.font.bold=bold; p.font.color.rgb=rgb(color)
        if align is not None: p.alignment=align
    return box

def base_slide(p,title,kicker='AUDITORÍA DE CONTRATACIÓN'):
    s=p.slides.add_slide(p.slide_layouts[6]); rect(s,0,0,13.333,7.5,COLORS['white'])
    rect(s,0,0,0.13,7.5,COLORS['cyan']); text(s,kicker,0.68,0.35,10,0.35,11,COLORS['blue'],True)
    text(s,title,0.68,0.9,11.9,0.85,30,COLORS['navy'],True)
    rect(s,0.68,1.87,11.95,0.018,'DCE5EF'); return s

def card(slide,x,y,w,h,heading,body,accent='2764D8'):
    rect(slide,x,y,w,h,COLORS['pale'],True); rect(slide,x,y,0.065,h,accent)
    text(slide,heading,x+0.24,y+0.24,w-0.45,0.5,21,COLORS['navy'],True)
    text(slide,body,x+0.24,y+0.9,w-0.48,h-1.0,16,COLORS['muted'])

def footer(slide,n):
    text(slide,'OPERACIÓN CONTRATO FANTASMA  /  FORMACIÓN PYTHON',0.68,7.09,10,0.24,9,COLORS['muted'])
    text(slide,str(n),12.2,7.09,0.4,0.24,9,COLORS['muted'])
