"""Proyecto final: presentación ejecutiva, con datos y gráfico generado en Python.
Ejecutar desde la raíz: python scripts/generar_presentacion.py
"""
from pathlib import Path
import sys
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'scripts'))
from diseno import *
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

OUT=ROOT/'salidas'; OUT.mkdir(exist_ok=True)
df=pd.read_csv(ROOT/'datos'/'auditoria_resumen.csv')
fig,ax=plt.subplots(figsize=(9,4.5))
ax.barh(df['departamento'],df['contratos'],color='#2764D8')
ax.invert_yaxis(); ax.set_xlabel('Número de contratos'); ax.spines[['top','right']].set_visible(False)
fig.tight_layout(); chart=OUT/'contratos_departamento.png'; fig.savefig(chart,dpi=170,transparent=True); plt.close(fig)
p=make_presentation()
# 1. Portada: composición editorial
s=p.slides.add_slide(p.slide_layouts[6]); rect(s,0,0,13.333,7.5,COLORS['navy']); rect(s,9.8,0,3.533,7.5,COLORS['blue'])
rect(s,10.15,1.1,2.6,0.11,COLORS['cyan']); rect(s,10.15,1.5,1.9,0.11,COLORS['cyan'])
text(s,'INFORME EJECUTIVO',0.9,1.25,8,0.4,14,COLORS['cyan'],True)
text(s,'Operación\nContrato Fantasma',0.9,2.0,9,2.0,43,COLORS['white'],True)
text(s,'Auditoría de contratación pública · Datos simulados',0.9,5.45,9,0.7,19,'D7E6F7')
# 2. KPIs
s=base_slide(p,'Panorama general'); total=int(df['contratos'].sum()); incid=int(df['alertas'].sum())
card(s,0.7,2.3,3.7,3.5,'Contratos',f'{total:,}\nRegistros analizados')
card(s,4.8,2.3,3.7,3.5,'Alertas',f'{incid:,}\nCasos para revisión',COLORS['orange'])
card(s,8.9,2.3,3.7,3.5,'Departamentos',f'{len(df)}\nUnidades evaluadas',COLORS['cyan']); footer(s,2)
# 3. Gráfico
s=base_slide(p,'¿Dónde se concentran los contratos?'); s.shapes.add_picture(str(chart), Inches(0.9), Inches(2.2), width=Inches(8.2))
card(s,9.4,2.55,3.1,3.15,'Lectura', 'El volumen no demuestra irregularidad: contrastar con presupuesto, actividad y controles.',COLORS['cyan']); footer(s,3)
# 4. Recomendaciones
s=base_slide(p,'De los indicadores a las decisiones')
card(s,0.7,2.3,5.75,3.55,'01 · Verificar','Revisar expedientes y documentación de contratos señalados.')
card(s,6.85,2.3,5.75,3.55,'02 · Contrastar','Comparar adjudicaciones con procedimientos, fechas y proveedores.',COLORS['cyan']); footer(s,4)
# 5. Cierre
s=base_slide(p,'Conclusión ejecutiva')
rect(s,0.75,2.4,11.8,2.45,COLORS['navy'],True)
text(s,'Una alerta es una señal para investigar,\nno una prueba de incumplimiento.',1.2,3.0,10.8,1.35,28,COLORS['white'],True)
text(s,'Próximo paso: validación documental y trazabilidad de los hallazgos.',0.9,5.45,11.5,0.6,19,COLORS['muted']); footer(s,5)
output=OUT/'Auditoria_Ejecutiva_Ejemplo.pptx'; p.save(output); print(f'Generado: {output}')
