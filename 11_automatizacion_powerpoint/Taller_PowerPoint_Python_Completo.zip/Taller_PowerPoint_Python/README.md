# Taller: PowerPoints profesionales con Python

**Duración sugerida:** 90 minutos. **Entregable:** una presentación ejecutiva editable en formato `.pptx`.

## Instalación en macOS

```bash
cd Taller_PowerPoint_Python
python3 -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
jupyter lab
```

Abre `notebooks/01_Taller_PowerPoint_Profesional.ipynb`. Para ejecutar directamente el proyecto:

```bash
python scripts/generar_presentacion.py
```

El resultado se guarda en `salidas/Auditoria_Ejecutiva_Ejemplo.pptx`.

## Cronograma

| Minutos | Trabajo |
|---|---|
| 0–10 | Principios de diseño y lectura de un deck |
| 10–25 | Crear diapositivas, formas y texto |
| 25–40 | Sistema visual y componentes reutilizables |
| 40–55 | Gráficos de datos y narración |
| 55–70 | Proyecto guiado completo |
| 70–85 | Diez ejercicios progresivos |
| 85–90 | Revisión y checklist final |

## Material

- `notebooks/`: teoría, ejemplos, retos y soluciones orientativas.
- `scripts/diseno.py`: componentes reutilizables.
- `scripts/generar_presentacion.py`: generador ejecutable de ejemplo.
- `datos/`: datos ficticios para prácticas.
- `salidas/`: gráficos y PPTX generados.

## Criterios de calidad

1. Una idea principal por diapositiva.
2. Titulares que comuniquen conclusiones, no solo temas.
3. Contraste, márgenes y jerarquía tipográfica.
4. No comprimir diagramas ni tablas hasta volverlos ilegibles.
5. Cambiar la composición según el contenido.
6. Mantener elementos editables siempre que sea posible.
7. Separar datos, estilo y lógica de generación.
8. Comprobar el archivo final en PowerPoint o LibreOffice.

**Nota:** la presentación generada es un ejemplo para que el alumnado estudie el código; no sustituye el PowerPoint docente del formador.
