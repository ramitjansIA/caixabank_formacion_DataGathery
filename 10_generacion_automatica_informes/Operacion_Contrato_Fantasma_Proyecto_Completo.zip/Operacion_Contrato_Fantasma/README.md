# OPERACIÓN CONTRATO FANTASMA
## Proyecto guiado de auditoría de datos en Python (90 minutos)

**Caso:** un ayuntamiento ficticio pide una revisión preliminar de su contratación. Los datos son sintéticos. El objetivo es identificar **señales de riesgo**, nunca declarar fraude automáticamente.

### Requisitos
Python 3.10 o superior, conexión a internet solo para instalar dependencias y, opcionalmente, enviar correo. No hace falta servidor de base de datos: SQLite viene con Python.

### Preparación (profesor, antes de clase)
En una terminal situada en esta carpeta:

**Windows PowerShell**
```powershell
py -m venv .venv
.venv\Scripts\Activate.ps1
python -m pip install -r requirements.txt
python ejecutar_todo.py
```
**macOS / Linux**
```bash
python3 -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
python ejecutar_todo.py
```
Se crearán `datos/contratos.sqlite` y `salidas/` con CSV, gráficos PNG, PDF, HTML y un mensaje `.eml`. **No se envía ningún correo** sin `--enviar`.

## Guion docente minuto a minuto

### 00–10 min — Presentación del caso
**Historia:** la interventora del Ayuntamiento de Puerto Claro recibe una denuncia anónima: “se repiten contratos de alumbrado con un mismo proveedor”. El equipo de auditoría debe producir un informe preliminar. Discutir qué es un *indicio* y por qué no equivale a una prueba.

**Actividad:** preguntar: ¿qué campos pediríamos para investigar? Fecha, expediente, proveedor, departamento, objeto, importe y procedimiento. Los alumnos localizan estas columnas en `01_crear_base.py`.

### 10–25 min — Construir la base y consultar SQL
Ejecutar:
```bash
python scripts/01_crear_base.py
```
Explicar `sqlite3.connect`, `CREATE TABLE`, claves primarias y foráneas, `INSERT`, `JOIN` y reproducibilidad (`random.seed`). Mostrar el siguiente ejemplo en un intérprete Python o notebook:
```python
import sqlite3
import pandas as pd
con = sqlite3.connect('datos/contratos.sqlite')
consulta = '''
SELECT p.nombre AS proveedor, COUNT(*) AS contratos,
       ROUND(SUM(c.importe),2) AS total
FROM contratos c
JOIN proveedores p ON c.proveedor_id=p.id
GROUP BY p.nombre
ORDER BY total DESC
'''
print(pd.read_sql_query(consulta, con).head())
con.close()
```
**Reto:** modificar la consulta para agrupar por departamento. Identificar qué hace `GROUP BY`.

### 25–45 min — Investigar alertas
Ejecutar:
```bash
python scripts/02_analizar.py
```
Abrir `salidas/cerca_umbral.csv`, `salidas/posible_fragmentacion.csv`, `salidas/posibles_duplicados.csv` y `salidas/resumen_proveedores.csv`.

**Explicación de las reglas:**
1. **Importes próximos al umbral ilustrativo:** contrato menor con importe entre 14.000 y 15.000 €. Es un criterio de ejercicio, **no un límite jurídico general**.
2. **Posible fraccionamiento:** al menos 3 contratos menores con igual proveedor, departamento y objeto dentro de 30 días. Las ventanas se pueden solapar: no sumar el número de ventanas como si fueran casos distintos.
3. **Posibles duplicados:** coincidencia de fecha, proveedor, departamento, objeto e importe, con expedientes diferentes. Revisar documentos antes de afirmar duplicidad real.
4. **Concentración:** cuota del gasto adjudicado por proveedor. Una cuota elevada por sí sola no es irregular.

**Reto:** cambiar el filtro de proximidad al umbral de 14.000 a 14.500 y comparar el número de alertas. Explicar falsos positivos.

### 45–58 min — Crear visualizaciones
En `02_analizar.py` identificar `groupby`, `agg`, `sort_values`, `plt.barh`, `plt.bar`, `savefig` y `tight_layout`.
Abrir `salidas/gasto_proveedores.png` y `salidas/gasto_departamentos.png`.

**Reto:** cambiar el título del gráfico o el color de las barras. Interpretar: ¿cuál es el proveedor con más gasto? ¿Es lo mismo tener más contratos que tener más gasto?

### 58–73 min — Generar el informe PDF
Ejecutar:
```bash
python scripts/03_informe_pdf.py
```
Abrir `salidas/Informe_Operacion_Contrato_Fantasma.pdf`. Explicar `SimpleDocTemplate`, `Paragraph`, `Table`, `Image` y el pie de página. El informe incorpora los comentarios del JSON y los gráficos creados en el paso anterior.

**Reto:** añadir un comentario propio al apartado de recomendaciones y regenerar el PDF. Diferenciar observación, riesgo, evidencia y recomendación.

### 73–85 min — Preparar y enviar el correo
Ejecutar primero el modo seguro:
```bash
python scripts/04_email.py
```
Abrir `salidas/vista_previa_email.html` en el navegador y `salidas/correo_preparado.eml` en un cliente de correo compatible. El correo contiene un resumen calculado, un gráfico PNG incrustado mediante Content-ID y el PDF adjunto.

**Para envío real, solo el profesor o alumnos autorizados:** copiar `.env.example` a `.env`, introducir servidor SMTP, puerto, usuario, contraseña de aplicación o credencial SMTP y destinatario autorizado. Nunca incluir contraseñas en el código ni subir `.env` a repositorios. En Gmail, normalmente se necesita una contraseña de aplicación con verificación en dos pasos, si la cuenta lo permite.
```bash
python scripts/04_email.py --enviar
```
La salida confirmará el envío si el servidor SMTP acepta el mensaje. La recepción final depende del proveedor de correo.

### 85–90 min — Debate y cierre
Preguntas: ¿qué alerta investigarías primero y por qué? ¿Qué documentos adicionales pedirías? ¿Qué sesgos tiene la selección de alertas? ¿Por qué no podemos afirmar fraude a partir de coincidencias estadísticas?

## Entregables del alumno
- Base de datos SQLite con las tres tablas relacionadas.
- CSV de contratos y alertas.
- Dos gráficos PNG.
- PDF de auditoría preliminar.
- Vista HTML y mensaje `.eml` (o correo enviado si está autorizado).

## Estructura
```
Operacion_Contrato_Fantasma/
├── ejecutar_todo.py
├── requirements.txt
├── .env.example
├── README.md
├── scripts/
│   ├── 01_crear_base.py
│   ├── 02_analizar.py
│   ├── 03_informe_pdf.py
│   └── 04_email.py
├── datos/
│   └── contratos.sqlite
└── salidas/
    ├── contratos.csv
    ├── cerca_umbral.csv
    ├── posible_fragmentacion.csv
    ├── posibles_duplicados.csv
    ├── resumen_proveedores.csv
    ├── indicadores.json
    ├── gasto_proveedores.png
    ├── gasto_departamentos.png
    ├── Informe_Operacion_Contrato_Fantasma.pdf
    ├── vista_previa_email.html
    └── correo_preparado.eml
```

## Ampliaciones opcionales (después de clase)
- Crear un indicador de gasto por mes.
- Identificar proveedores con alto número de contratos pero gasto relativamente bajo.
- Implementar pruebas unitarias para las reglas de alerta.
- Añadir un apartado de limitaciones legales y procedimentales.

## Aviso
El conjunto es ficticio. Los importes y reglas son criterios didácticos, no asesoramiento jurídico ni detección concluyente de fraude. En una auditoría real, validar umbrales, tipo de contrato, excepciones, periodo, jurisdicción y documentación.
