"""Crea una base SQLite reproducible con casos sintéticos de riesgo."""
import random
import sqlite3
from datetime import datetime, timedelta
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
DB = ROOT / 'datos' / 'contratos.sqlite'
random.seed(2026)
DB.parent.mkdir(parents=True, exist_ok=True)

PROVEEDORES = [(1,'Infraestructura Delta SL'),(2,'Servicios Horizonte SL'),(3,'Consultoría Nexo SL'),(4,'Obras Litoral SL'),(5,'Tecnología Atlas SL'),(6,'Suministros Prado SL'),(7,'Gestión Boreal SL'),(8,'Construcciones Vega SL')]
DEPARTAMENTOS = [(1,'Urbanismo'),(2,'Tecnología'),(3,'Cultura'),(4,'Mantenimiento')]

with sqlite3.connect(DB) as con:
    con.executescript('''
    DROP TABLE IF EXISTS contratos;
    DROP TABLE IF EXISTS proveedores;
    DROP TABLE IF EXISTS departamentos;
    CREATE TABLE proveedores (id INTEGER PRIMARY KEY, nombre TEXT NOT NULL);
    CREATE TABLE departamentos (id INTEGER PRIMARY KEY, nombre TEXT NOT NULL);
    CREATE TABLE contratos (
        id INTEGER PRIMARY KEY, fecha TEXT NOT NULL, proveedor_id INTEGER NOT NULL,
        departamento_id INTEGER NOT NULL, objeto TEXT NOT NULL,
        importe REAL NOT NULL CHECK(importe > 0), procedimiento TEXT NOT NULL,
        expediente TEXT NOT NULL UNIQUE,
        FOREIGN KEY(proveedor_id) REFERENCES proveedores(id),
        FOREIGN KEY(departamento_id) REFERENCES departamentos(id)
    );
    ''')
    con.executemany('INSERT INTO proveedores VALUES (?,?)', PROVEEDORES)
    con.executemany('INSERT INTO departamentos VALUES (?,?)', DEPARTAMENTOS)
    rows=[]
    base=datetime(2026,1,1)
    objetos=['Mantenimiento de edificios','Reparación de alumbrado','Licencias informáticas','Servicios culturales','Obras menores','Asistencia técnica']
    for i in range(1,221):
        fecha=(base+timedelta(days=random.randrange(280))).strftime('%Y-%m-%d')
        proveedor=random.choices(range(1,9), weights=[10,11,12,10,9,10,8,10])[0]
        departamento=random.randint(1,4)
        importe=round(random.uniform(1200,23000),2)
        procedimiento='Menor' if importe < 15000 else 'Abierto simplificado'
        rows.append((i,fecha,proveedor,departamento,random.choice(objetos),importe,procedimiento,f'EXP-2026-{i:04d}'))
    # Patrón deliberado: seis contratos próximos al umbral pedagógico de 15.000 €,
    # mismo proveedor, departamento, objeto y ventana temporal.
    for i in range(221,227):
        rows.append((i,f'2026-06-{10+i-221:02d}',2,1,'Reparación de alumbrado',14900+i-221,'Menor',f'EXP-2026-{i:04d}'))
    # Patrón deliberado: concentración de adjudicaciones.
    for i in range(227,247):
        rows.append((i,(base+timedelta(days=120+i-227)).strftime('%Y-%m-%d'),3,2,'Licencias informáticas',round(4500+random.random()*2500,2),'Menor',f'EXP-2026-{i:04d}'))
    # Duplicidad exacta de campos de negocio (expediente distinto).
    rows.append((247,'2026-09-08',5,4,'Mantenimiento de edificios',8750.00,'Menor','EXP-2026-0247'))
    rows.append((248,'2026-09-08',5,4,'Mantenimiento de edificios',8750.00,'Menor','EXP-2026-0248'))
    con.executemany('INSERT INTO contratos VALUES (?,?,?,?,?,?,?,?)', rows)
    con.commit()
print(f'Base creada: {DB} | {len(rows)} contratos')
