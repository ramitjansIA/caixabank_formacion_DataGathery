"""Prepara correo HTML y PDF adjunto. Solo envía con --enviar."""
import argparse
import json
import os
import smtplib
from email.message import EmailMessage
from pathlib import Path
from dotenv import load_dotenv

ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'salidas'
load_dotenv(ROOT/'.env')
p=argparse.ArgumentParser();p.add_argument('--enviar',action='store_true',help='Realiza el envío SMTP (por defecto, solo previsualiza)');args=p.parse_args()
info=json.loads((OUT/'indicadores.json').read_text(encoding='utf-8'))
i=info['indicadores']; comentarios=info['comentarios'];pdf=OUT/'Informe_Operacion_Contrato_Fantasma.pdf'
if not pdf.exists():raise SystemExit('Falta el PDF: ejecuta scripts/03_informe_pdf.py')
li=''.join(f'<li style="margin:7px 0">{c}</li>' for c in comentarios)
html=f'''<html><body style="font-family:Arial,sans-serif;color:#183B47;max-width:680px;margin:auto">
<h1 style="color:#126478">Operación Contrato Fantasma</h1><p>Informe automatizado de auditoría preliminar (datos ficticios).</p>
<div style="background:#E9F5F7;padding:16px;border-radius:8px"><b>{i['n_contratos']} contratos</b> · <b>{i['gasto_total']:,.2f} €</b> analizados · <b>{i['n_cerca_umbral']} alertas</b> próximas al umbral</div>
<h2>Principales observaciones</h2><ul>{li}</ul>
<h2>Gasto por proveedor</h2><img src="cid:grafico_proveedores" alt="Gasto por proveedor" style="width:100%;max-width:650px"/>
<p>Adjuntamos el informe PDF con metodología, gráficos y alertas. Los indicios no prueban fraude.</p>
<p style="color:#777;font-size:12px">Caso didáctico: información íntegramente sintética.</p></body></html>'''
(OUT/'vista_previa_email.html').write_text(html.replace('cid:grafico_proveedores','gasto_proveedores.png'),encoding='utf-8')
msg=EmailMessage();msg['Subject']='[Caso docente] Informe automatizado — Operación Contrato Fantasma'
msg['From']=os.getenv('EMAIL_FROM') or os.getenv('SMTP_USER') or 'simulacion@example.invalid'
msg['To']=os.getenv('EMAIL_TO') or 'destinatario@example.invalid'
msg.set_content('Informe preliminar de auditoría. Se adjunta el PDF con gráficos y hallazgos. Datos sintéticos.')
msg.add_alternative(html,subtype='html')
with (OUT/'gasto_proveedores.png').open('rb') as f:
    msg.get_payload()[1].add_related(f.read(),maintype='image',subtype='png',cid='<grafico_proveedores>',filename='gasto_proveedores.png')
msg.add_attachment(pdf.read_bytes(),maintype='application',subtype='pdf',filename=pdf.name)
if not args.enviar:
    (OUT/'correo_preparado.eml').write_bytes(msg.as_bytes())
    print('SIMULACIÓN: correo .eml y vista HTML generados. No se ha enviado ningún mensaje.')
else:
    required=['SMTP_HOST','SMTP_PORT','SMTP_USER','SMTP_PASSWORD','EMAIL_TO']
    missing=[k for k in required if not os.getenv(k)]
    if missing:raise SystemExit('Faltan variables en .env: '+', '.join(missing))
    host=os.environ['SMTP_HOST'];port=int(os.environ['SMTP_PORT'])
    if port not in (465,587):raise SystemExit('Usa SMTP seguro por puerto 465 (SSL) o 587 (STARTTLS).')
    if port==465:
        from smtplib import SMTP_SSL
        with SMTP_SSL(host,port,timeout=20) as s:
            s.login(os.environ['SMTP_USER'],os.environ['SMTP_PASSWORD']);s.send_message(msg)
    else:
        with smtplib.SMTP(host,port,timeout=20) as s:
            s.ehlo();s.starttls();s.ehlo();s.login(os.environ['SMTP_USER'],os.environ['SMTP_PASSWORD']);s.send_message(msg)
    print('Correo enviado al destinatario configurado:',os.environ['EMAIL_TO'])
