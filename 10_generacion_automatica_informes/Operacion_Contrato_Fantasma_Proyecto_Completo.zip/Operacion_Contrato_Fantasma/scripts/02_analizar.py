"""Analiza patrones de riesgo. Las alertas no constituyen pruebas de fraude."""
import json
import sqlite3
from pathlib import Path
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'salidas'; OUT.mkdir(exist_ok=True)
DB=ROOT/'datos'/'contratos.sqlite'
if not DB.exists():
    raise SystemExit('Falta la base de datos: ejecuta scripts/01_crear_base.py')
with sqlite3.connect(DB) as con:
    df=pd.read_sql_query('''SELECT c.*, p.nombre AS proveedor, d.nombre AS departamento
       FROM contratos c JOIN proveedores p ON p.id=c.proveedor_id
       JOIN departamentos d ON d.id=c.departamento_id''',con)
df['fecha']=pd.to_datetime(df['fecha'])
# Regla 1: posibles contratos próximos al umbral didáctico de 15.000 €.
# No es un umbral legal universal: debe adaptarse a la normativa y tipo de contrato.
cerca=df[(df.procedimiento=='Menor') & (df.importe.between(14000,15000,inclusive='left'))].copy()
# Regla 2: posible fragmentación: 3+ contratos del mismo proveedor,
# departamento y objeto dentro de una ventana móvil de 30 días.
fragmentacion=[]
for clave, grupo in df[df.procedimiento=='Menor'].groupby(['proveedor','departamento','objeto']):
    grupo=grupo.sort_values('fecha')
    for _, fila in grupo.iterrows():
        ventana=grupo[(grupo.fecha>=fila.fecha)&(grupo.fecha<=fila.fecha+pd.Timedelta(days=30))]
        if len(ventana)>=3:
            fragmentacion.append({'proveedor':clave[0],'departamento':clave[1], 'objeto':clave[2], 'inicio':str(fila.fecha.date()), 'n_contratos':len(ventana), 'importe_total':round(float(ventana.importe.sum()),2), 'expedientes':', '.join(ventana.expediente)})
fragmentacion=pd.DataFrame(fragmentacion).drop_duplicates(subset=['proveedor','departamento','objeto','expedientes']) if fragmentacion else pd.DataFrame(columns=['proveedor','departamento','objeto','inicio','n_contratos','importe_total','expedientes'])
# Regla 3: contratos idénticos en fecha/proveedor/departamento/objeto/importe.
duplicados=df[df.duplicated(['fecha','proveedor','departamento','objeto','importe'],keep=False)].sort_values(['proveedor','fecha'])
# Regla 4: concentración de gasto por proveedor.
proveedores=df.groupby('proveedor',as_index=False).agg(contratos=('id','count'),gasto=('importe','sum')).sort_values('gasto',ascending=False)
proveedores['cuota_pct']=(100*proveedores.gasto/df.importe.sum()).round(1)
por_depto=df.groupby('departamento',as_index=False).importe.sum().sort_values('importe',ascending=False)

for name, data in [('contratos',df),('cerca_umbral',cerca),('posible_fragmentacion',fragmentacion),('posibles_duplicados',duplicados),('resumen_proveedores',proveedores)]:
    data.to_csv(OUT/f'{name}.csv',index=False,encoding='utf-8-sig')

plt.rcParams.update({'font.size':10})
fig,ax=plt.subplots(figsize=(9,4.5))
ax.barh(proveedores.proveedor.iloc[::-1],proveedores.gasto.iloc[::-1],color='#167D8D')
ax.set_title('Gasto adjudicado por proveedor'); ax.set_xlabel('Importe (€)')
ax.grid(axis='x',alpha=.2); fig.tight_layout(); fig.savefig(OUT/'gasto_proveedores.png',dpi=160); plt.close(fig)
fig,ax=plt.subplots(figsize=(8,4))
ax.bar(por_depto.departamento,por_depto.importe,color='#E09B43')
ax.set_title('Gasto por departamento'); ax.set_ylabel('Importe (€)'); ax.tick_params(axis='x',rotation=12)
fig.tight_layout(); fig.savefig(OUT/'gasto_departamentos.png',dpi=160); plt.close(fig)

indicadores={
 'n_contratos':int(len(df)), 'gasto_total':round(float(df.importe.sum()),2),
 'n_cerca_umbral':int(len(cerca)), 'n_ventanas_fragmentacion':int(len(fragmentacion)),
 'n_registros_duplicados':int(len(duplicados)),
 'proveedor_principal':str(proveedores.iloc[0].proveedor),
 'cuota_principal':float(proveedores.iloc[0].cuota_pct),
 'departamento_mayor_gasto':str(por_depto.iloc[0].departamento),
}
comentarios=[f"Se han examinado {indicadores['n_contratos']} contratos por {indicadores['gasto_total']:,.2f} €.",
 f"Hay {indicadores['n_cerca_umbral']} contratos menores entre 14.000 € y 15.000 €; requieren revisión contextual, no implican infracción.",
 f"Se identificaron {indicadores['n_ventanas_fragmentacion']} ventanas de 30 días con tres o más contratos similares; pueden solaparse.",
 f"Existen {indicadores['n_registros_duplicados']} registros en grupos de posible duplicidad; comprobar facturas y expedientes.",
 f"El proveedor con mayor gasto es {indicadores['proveedor_principal']} ({indicadores['cuota_principal']:.1f}% del total).",
 'Las señales son criterios de priorización; se requiere evidencia documental y análisis jurídico antes de concluir irregularidades.']
(OUT/'indicadores.json').write_text(json.dumps({'indicadores':indicadores,'comentarios':comentarios},ensure_ascii=False,indent=2),encoding='utf-8')
print('\n'.join(comentarios))
print('Gráficos, tablas e indicadores guardados en:',OUT)
