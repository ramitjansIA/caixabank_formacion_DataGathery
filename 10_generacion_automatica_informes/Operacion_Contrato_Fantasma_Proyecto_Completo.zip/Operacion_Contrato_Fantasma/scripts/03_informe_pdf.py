"""Genera un informe PDF con resumen, gráficos y hallazgos verificables."""
import json
from pathlib import Path
from xml.sax.saxutils import escape
import pandas as pd
from reportlab.platypus import SimpleDocTemplate,Paragraph,Spacer,Image,Table,TableStyle,KeepTogether
from reportlab.lib import colors
from reportlab.lib.styles import getSampleStyleSheet,ParagraphStyle
from reportlab.lib.enums import TA_CENTER
from reportlab.lib.units import cm

ROOT=Path(__file__).resolve().parents[1]; OUT=ROOT/'salidas'
info=json.loads((OUT/'indicadores.json').read_text(encoding='utf-8'))
frag=pd.read_csv(OUT/'posible_fragmentacion.csv')
dup=pd.read_csv(OUT/'posibles_duplicados.csv')
path=OUT/'Informe_Operacion_Contrato_Fantasma.pdf'
styles=getSampleStyleSheet(); styles.add(ParagraphStyle(name='TituloAudit',parent=styles['Title'],textColor=colors.HexColor('#12495B'),fontSize=19,leading=23,spaceAfter=14))
styles.add(ParagraphStyle(name='SubAudit',parent=styles['Heading2'],textColor=colors.HexColor('#12495B'),spaceBefore=14))
doc=SimpleDocTemplate(str(path),pagesize=(21*cm,29.7*cm),rightMargin=1.7*cm,leftMargin=1.7*cm,topMargin=1.6*cm,bottomMargin=1.6*cm)
story=[Paragraph('OPERACIÓN CONTRATO FANTASMA',styles['TituloAudit']),Paragraph('Informe de análisis preliminar de contratación pública · Caso didáctico con datos sintéticos',styles['Normal']),Spacer(1,14)]
I=info['indicadores']
metricas=[['Contratos analizados','Gasto total','Cerca del umbral'],[str(I['n_contratos']),f"{I['gasto_total']:,.2f} €",str(I['n_cerca_umbral'])]]
t=Table(metricas,colWidths=[5.5*cm]*3,rowHeights=[0.8*cm,1.1*cm]);t.setStyle(TableStyle([('BACKGROUND',(0,0),(-1,0),colors.HexColor('#DCEFF2')),('TEXTCOLOR',(0,0),(-1,-1),colors.HexColor('#12495B')),('ALIGN',(0,0),(-1,-1),'CENTER'),('GRID',(0,0),(-1,-1),0.3,colors.HexColor('#B8CED4'))]));story.append(t)
story.append(Paragraph('1. Resumen ejecutivo',styles['SubAudit']))
for comentario in info['comentarios']:
    story.append(Paragraph('• '+escape(comentario),styles['BodyText']));story.append(Spacer(1,5))
story.append(Paragraph('2. Distribución de las adjudicaciones',styles['SubAudit']))
for img in ['gasto_proveedores.png','gasto_departamentos.png']:
    story.append(Image(str(OUT/img),width=16.7*cm,height=8.1*cm))
story.append(Paragraph('3. Ejemplos de alertas para revisión',styles['SubAudit']))
if len(frag):
    f=frag.sort_values('n_contratos',ascending=False).iloc[0]
    story.append(Paragraph(f"Posible fraccionamiento: {escape(str(f['proveedor']))}, {escape(str(f['departamento']))}, {int(f['n_contratos'])} contratos en 30 días; importe agregado {float(f['importe_total']):,.2f} €.",styles['BodyText']))
if len(dup):
    story.append(Paragraph('Posible duplicidad: expedientes '+escape(', '.join(dup.expediente.head(5).astype(str)))+'. Verificar si corresponden a prestaciones diferentes.',styles['BodyText']))
story.append(Paragraph('4. Metodología y limitaciones',styles['SubAudit']))
story.append(Paragraph('Análisis descriptivo con SQL y Pandas. Reglas didácticas: importes entre 14.000 y 15.000 €, ventanas móviles de 30 días con tres o más registros similares, coincidencia exacta de campos y concentración por proveedor. El umbral es ilustrativo y no sustituye los límites legales aplicables según contrato, periodo y jurisdicción. Las ventanas pueden solaparse; no se deben interpretar como incidentes independientes.',styles['BodyText']))
story.append(Spacer(1,10));story.append(Paragraph('Recomendación: solicitar expedientes, pliegos, facturas y justificaciones, y contrastar los indicios con normativa vigente antes de emitir conclusiones.',styles['BodyText']))
def footer(canvas,doc):
    canvas.setFont('Helvetica',8);canvas.setFillColor(colors.grey);canvas.drawString(1.7*cm,1*cm,'CASO FICTICIO · SOLO FINES DOCENTES');canvas.drawRightString(19.3*cm,1*cm,f'Página {doc.page}')
doc.build(story,onFirstPage=footer,onLaterPages=footer)
print('PDF generado:',path)
