"""Ejecuta las cuatro etapas. El envío real requiere --enviar."""
import subprocess
import sys
from pathlib import Path
import argparse
p=argparse.ArgumentParser();p.add_argument('--enviar',action='store_true');args=p.parse_args()
root=Path(__file__).resolve().parent
for nombre in ['01_crear_base.py','02_analizar.py','03_informe_pdf.py','04_email.py']:
    cmd=[sys.executable,str(root/'scripts'/nombre)]
    if nombre=='04_email.py' and args.enviar:cmd.append('--enviar')
    print('\n>>>',nombre,flush=True)
    subprocess.run(cmd,check=True)
