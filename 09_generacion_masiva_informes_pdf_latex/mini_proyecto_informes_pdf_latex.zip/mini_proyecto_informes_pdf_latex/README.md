# Mini-proyecto: generación masiva de informes PDF con LaTeX

## Python
pip install pandas jinja2

## Motor LaTeX
Instalar TeX Live o MiKTeX para compilar PDF.

## Estructura
- data/: datos
- templates/: plantilla LaTeX/Jinja2
- outputs/tex/: .tex generados
- outputs/pdf/: PDFs
- logs/: auditoría
- src/: código reusable
