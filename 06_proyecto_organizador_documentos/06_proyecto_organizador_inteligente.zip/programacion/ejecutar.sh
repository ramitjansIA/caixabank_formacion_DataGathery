#!/bin/bash
# Simula por defecto. No instala tareas. Configura ambas variables con rutas absolutas.
set -u
: "${AULA_PYTHON:?Define AULA_PYTHON como ruta absoluta al intérprete}"
: "${AULA_PROYECTO:?Define AULA_PROYECTO como ruta absoluta a la demo}"
codigo=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd) || exit 30
case "$AULA_PYTHON" in /*) ;; *) exit 20 ;; esac
case "$AULA_PROYECTO" in /*) ;; *) exit 20 ;; esac
if [ "$#" -gt 1 ]; then exit 2; fi
case "${1:-}" in
  "") set -- ;;
  --aplicar) set -- --aplicar ;;
  *) exit 2 ;;
esac
exec "$AULA_PYTHON" "$codigo/organizador.py" ejecutar --proyecto "$AULA_PROYECTO" "$@"
