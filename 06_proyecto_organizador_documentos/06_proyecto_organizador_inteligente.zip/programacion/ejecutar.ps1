# Simula por defecto. No registra tareas. -Aplicar habilita publicación ensayada.
param(
    [Parameter(Mandatory=$true)][string]$PythonExe,
    [Parameter(Mandatory=$true)][string]$Proyecto,
    [switch]$Aplicar
)
$ErrorActionPreference = 'Stop'
try {
    if (-not [IO.Path]::IsPathRooted($PythonExe) -or -not [IO.Path]::IsPathRooted($Proyecto)) {
        throw 'Se requieren rutas absolutas'
    }
    if (-not (Test-Path -LiteralPath $PythonExe -PathType Leaf)) { throw 'Intérprete ausente' }
    $motor = Join-Path (Split-Path $PSScriptRoot -Parent) 'organizador.py'
    $estado = Join-Path $Proyecto 'estado'
    if (-not (Test-Path -LiteralPath $estado -PathType Container)) { throw 'Demo ausente' }
    $id = [guid]::NewGuid().ToString('N')
    $salida = Join-Path $estado ('stdout_' + $id + '.log')
    $errorLog = Join-Path $estado ('stderr_' + $id + '.log')
    $argumentos = @($motor, 'ejecutar', '--proyecto', $Proyecto)
    if ($Aplicar) { $argumentos += '--aplicar' }
    & $PythonExe @argumentos 1> $salida 2> $errorLog
    $codigo = $LASTEXITCODE
    exit $codigo
} catch {
    Write-Error $_ -ErrorAction Continue
    exit 30
}
