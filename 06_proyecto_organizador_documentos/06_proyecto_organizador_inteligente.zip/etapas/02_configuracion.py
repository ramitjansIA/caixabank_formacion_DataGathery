# Punto de control autocontenido; usa copias_seguridad.py de la carpeta padre.
from pathlib import Path
import sys
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
"""Organizador del observatorio, Python 3.11+. Solo proyectos sintéticos privados.
Conserva origen, clasifica por reglas y no sobrescribe destinos.
Reutiliza copias_seguridad.py del bloque 05, incluido al lado.
"""
from pathlib import Path, PurePosixPath
from collections import Counter, defaultdict
from datetime import date, datetime, timezone
import argparse
import json
import logging
import re
import sys
import uuid
import copias_seguridad as backup

REGLAS = {
    "schema": 1,
    "tipos": {
        "datos": {"sufijo": ".csv", "carpeta": "datos"},
        "informe": {"sufijo": ".md", "carpeta": "informes"},
        "contexto": {"sufijo": ".json", "carpeta": "contexto"},
        "acta": {"sufijo": ".txt", "carpeta": "actas"},
    },
}
PATRON = (
    r"(?P<fecha>\d{4}-\d{2}-\d{2})_(?P<tipo>[a-z]+)_"
    r"(?P<id>DOC-\d{3})(?P<sufijo>\.[a-z]+)"
)
LOG = logging.getLogger("organizador")


def crear_demo(destino):
    """Etapa 01. Crear únicamente una raíz nueva con datos ficticios."""
    raiz = Path(destino).absolute()
    raiz.mkdir(parents=True, exist_ok=False, mode=0o700)
    for nombre in ("origen", "archivo", "informes", "copias", "restauraciones", "estado"):
        (raiz / nombre).mkdir()
    marca = {"tipo": "demo_copias", "schema": 1, "id": uuid.uuid4().hex}
    (raiz / "proyecto_backup.json").write_text(json.dumps(marca), encoding="utf-8")
    (raiz / "organizador.json").write_text(
        '{"schema":1,"tipo":"observatorio_aula"}', encoding="utf-8"
    )
    (raiz / "reglas.json").write_text(json.dumps(REGLAS, indent=2), encoding="utf-8")
    textos = {
        "equipo_a/2026-10-01_datos_DOC-001.csv": "id;importe\nDEMO-001;1200000\n",
        "equipo_b/2026-10-01_datos_DOC-001.csv": "id;importe\nDEMO-001;1200000\n",
        "2026-10-02_informe_DOC-002.md": "# Informe ficticio\nSolo datos de aula.\n",
        "2026-10-03_contexto_DOC-003.json": '{"territorio":"DEMO"}\n',
        "2026-10-04_acta_DOC-004.txt": "Acta ficticia del observatorio.\n",
        "sin_fecha.txt": "Pendiente de identificar.\n",
        "2026-02-30_informe_DOC-005.md": "Fecha imposible.\n",
        "2026-10-06_informe_DOC-006.txt": "Tipo y extension incompatibles.\n",
        "area_a/2026-10-07_informe_DOC-007.md": "Version A\n",
        "area_b/2026-10-07_informe_DOC-007.md": "Version B\n",
    }
    for relativa, texto in textos.items():
        p = raiz / "origen" / relativa
        p.parent.mkdir(parents=True, exist_ok=True)
        with p.open("x", encoding="utf-8", newline="\n") as f:
            f.write(texto)
    return raiz


def leer_json(ruta):
    """Etapa 02. Lectura acotada de un archivo real, sin enlaces."""
    if ruta.is_symlink() or not ruta.is_file():
        raise backup.ContratoError("Se requiere un JSON regular")
    with ruta.open("rb") as f:
        datos = f.read(65537)
    if len(datos) > 65536:
        raise backup.ContratoError("JSON de control demasiado grande")
    try:
        return backup.json_estricto(datos.decode("utf-8"))
    except (ValueError, UnicodeError) as error:
        raise backup.ContratoError("JSON de control inválido") from error


def cargar_proyecto(proyecto):
    raiz = backup.cargar_proyecto(proyecto)
    if leer_json(raiz / "organizador.json") != {"schema": 1, "tipo": "observatorio_aula"}:
        raise backup.ContratoError("No se reconoce el organizador de aula")
    for nombre in ("archivo", "informes"):
        p = raiz / nombre
        if p.is_symlink() or not p.is_dir():
            raise backup.ContratoError("Falta una carpeta real: " + nombre)
    return raiz


def cargar_reglas(raiz):
    reglas = leer_json(raiz / "reglas.json")
    if not isinstance(reglas, dict) or set(reglas) != {"schema", "tipos"}:
        raise backup.ContratoError("Campos de reglas incompatibles")
    if type(reglas["schema"]) is not int or reglas["schema"] != 1:
        raise backup.ContratoError("Versión de reglas incompatible")
    tipos = reglas["tipos"]
    if not isinstance(tipos, dict) or not 1 <= len(tipos) <= 20:
        raise backup.ContratoError("Se requieren entre 1 y 20 tipos")
    for tipo, regla in tipos.items():
        if not re.fullmatch(r"[a-z]+", tipo) or not isinstance(regla, dict):
            raise backup.ContratoError("Tipo o regla incompatible")
        if set(regla) != {"sufijo", "carpeta"}:
            raise backup.ContratoError("Campos de una regla incompatibles")
        sufijo = regla["sufijo"]
        if not isinstance(sufijo, str) or not re.fullmatch(r"\.[a-z]+", sufijo):
            raise backup.ContratoError("Sufijo incompatible")
        backup.nombre_simple(regla["carpeta"])
    return reglas

def main():
    p=argparse.ArgumentParser()
    p.add_argument("accion",choices=['crear-demo', 'inspeccionar'])
    p.add_argument("ruta",type=Path)
    p.add_argument("--nombre",default="2026-10-02_informe_DOC-002.md")
    p.add_argument("--aplicar",action="store_true")
    a=p.parse_args()
    if a.accion=="crear-demo":
        resultado={"proyecto":str(crear_demo(a.ruta))}
    elif a.accion=="inspeccionar":
        r=cargar_proyecto(a.ruta)
        resultado={"proyecto":str(r),"reglas":cargar_reglas(r)}
    print(json.dumps(resultado,ensure_ascii=False))
    return resultado.get("codigo",0)

if __name__=="__main__":
    raise SystemExit(main())
