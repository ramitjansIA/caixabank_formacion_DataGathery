# Punto de control autocontenido; usa copias_seguridad.py de la carpeta padre.
from pathlib import Path
import sys
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
"""Organizador del observatorio, Python 3.11+. Solo proyectos sintéticos privados.
Conserva origen, clasifica por reglas y no sobrescribe destinos.
Reutiliza copias_seguridad.py del bloque 05, incluido al lado.
"""
from pathlib import Path, PurePosixPath
from collections import Counter, defaultdict
from datetime import date, datetime, timezone
import argparse
import json
import logging
import re
import sys
import uuid
import copias_seguridad as backup

REGLAS = {
    "schema": 1,
    "tipos": {
        "datos": {"sufijo": ".csv", "carpeta": "datos"},
        "informe": {"sufijo": ".md", "carpeta": "informes"},
        "contexto": {"sufijo": ".json", "carpeta": "contexto"},
        "acta": {"sufijo": ".txt", "carpeta": "actas"},
    },
}
PATRON = (
    r"(?P<fecha>\d{4}-\d{2}-\d{2})_(?P<tipo>[a-z]+)_"
    r"(?P<id>DOC-\d{3})(?P<sufijo>\.[a-z]+)"
)
LOG = logging.getLogger("organizador")


def crear_demo(destino):
    """Etapa 01. Crear únicamente una raíz nueva con datos ficticios."""
    raiz = Path(destino).absolute()
    raiz.mkdir(parents=True, exist_ok=False, mode=0o700)
    for nombre in ("origen", "archivo", "informes", "copias", "restauraciones", "estado"):
        (raiz / nombre).mkdir()
    marca = {"tipo": "demo_copias", "schema": 1, "id": uuid.uuid4().hex}
    (raiz / "proyecto_backup.json").write_text(json.dumps(marca), encoding="utf-8")
    (raiz / "organizador.json").write_text(
        '{"schema":1,"tipo":"observatorio_aula"}', encoding="utf-8"
    )
    (raiz / "reglas.json").write_text(json.dumps(REGLAS, indent=2), encoding="utf-8")
    textos = {
        "equipo_a/2026-10-01_datos_DOC-001.csv": "id;importe\nDEMO-001;1200000\n",
        "equipo_b/2026-10-01_datos_DOC-001.csv": "id;importe\nDEMO-001;1200000\n",
        "2026-10-02_informe_DOC-002.md": "# Informe ficticio\nSolo datos de aula.\n",
        "2026-10-03_contexto_DOC-003.json": '{"territorio":"DEMO"}\n',
        "2026-10-04_acta_DOC-004.txt": "Acta ficticia del observatorio.\n",
        "sin_fecha.txt": "Pendiente de identificar.\n",
        "2026-02-30_informe_DOC-005.md": "Fecha imposible.\n",
        "2026-10-06_informe_DOC-006.txt": "Tipo y extension incompatibles.\n",
        "area_a/2026-10-07_informe_DOC-007.md": "Version A\n",
        "area_b/2026-10-07_informe_DOC-007.md": "Version B\n",
    }
    for relativa, texto in textos.items():
        p = raiz / "origen" / relativa
        p.parent.mkdir(parents=True, exist_ok=True)
        with p.open("x", encoding="utf-8", newline="\n") as f:
            f.write(texto)
    return raiz

def main():
    p=argparse.ArgumentParser()
    p.add_argument("accion",choices=['crear-demo'])
    p.add_argument("ruta",type=Path)
    p.add_argument("--nombre",default="2026-10-02_informe_DOC-002.md")
    p.add_argument("--aplicar",action="store_true")
    a=p.parse_args()
    if a.accion=="crear-demo":
        resultado={"proyecto":str(crear_demo(a.ruta))}
    print(json.dumps(resultado,ensure_ascii=False))
    return resultado.get("codigo",0)

if __name__=="__main__":
    raise SystemExit(main())
