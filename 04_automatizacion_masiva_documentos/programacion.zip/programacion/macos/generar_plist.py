"""Solo escribe una configuración launchd; no instala ni carga tareas."""
from pathlib import Path
import argparse
import plistlib


def construir_plist(proyecto):
    raiz = Path(proyecto).expanduser().resolve(strict=True)
    if not (raiz / ".venv/bin/python").is_file() or not (raiz / "trabajo_demo/config.json").is_file():
        raise ValueError("Prepara entorno virtual y datos demo antes de generar")
    # launchd no crea automáticamente los padres de sus rutas de registro.
    (raiz / "logs").mkdir(exist_ok=True)
    return {"Label":"com.cursoauto.bloque04", "ProgramArguments":[str(raiz / ".venv/bin/python"),"-u",str(raiz / "procesar_lote.py"),"--config",str(raiz / "trabajo_demo/config.json")], "WorkingDirectory":str(raiz), "StartCalendarInterval":{"Hour":9,"Minute":0}, "StandardOutPath":str(raiz / "logs/launchd.stdout.log"), "StandardErrorPath":str(raiz / "logs/launchd.stderr.log"), "RunAtLoad":False}


if __name__ == "__main__":
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument("--proyecto", required=True, type=Path)
    p.add_argument("--salida", required=True, type=Path)
    a=p.parse_args()
    contenido=plistlib.dumps(construir_plist(a.proyecto), sort_keys=False)
    with a.salida.open("xb") as f:
        f.write(contenido)
    print(a.salida)
