﻿param([switch]$Registrar)
$ErrorActionPreference = 'Stop'
$ProjectDir = Split-Path -Parent (Split-Path -Parent $PSScriptRoot)
$Wrapper = Join-Path $PSScriptRoot 'ejecutar.ps1'
$TaskName = 'CursoAuto_Bloque04_Demo'
$PowerShellExe = Join-Path $env:SystemRoot 'System32\WindowsPowerShell\v1.0\powershell.exe'
$Action = New-ScheduledTaskAction -Execute $PowerShellExe `
    -Argument ('-NoProfile -NonInteractive -File "{0}"' -f $Wrapper) `
    -WorkingDirectory $ProjectDir
$Trigger = New-ScheduledTaskTrigger -Daily -At '09:00'
$Settings = New-ScheduledTaskSettingsSet -MultipleInstances IgnoreNew `
    -StartWhenAvailable -ExecutionTimeLimit (New-TimeSpan -Minutes 10)
$Account = [System.Security.Principal.WindowsIdentity]::GetCurrent().Name
$Principal = New-ScheduledTaskPrincipal -UserId $Account -LogonType Interactive -RunLevel Limited
# Cuenta interactiva: requiere sesión iniciada. No guarda contraseñas ni usa SYSTEM.
if (-not $Registrar) {
    $Action | Format-List Execute,Arguments,WorkingDirectory
    Write-Output 'Vista previa: no se ha registrado ninguna tarea.'
    return
}
if (Get-ScheduledTask -TaskName $TaskName -ErrorAction SilentlyContinue) {
    throw 'Ya existe la tarea de curso. No se sustituye automáticamente.'
}
Register-ScheduledTask -TaskName $TaskName -Action $Action -Trigger $Trigger `
    -Settings $Settings -Principal $Principal -Description 'Lote sintético docente'
