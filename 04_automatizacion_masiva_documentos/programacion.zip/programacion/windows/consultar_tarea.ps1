﻿$TaskName = 'CursoAuto_Bloque04_Demo'
Get-ScheduledTask -TaskName $TaskName | Select-Object TaskName,State
Get-ScheduledTaskInfo -TaskName $TaskName | Format-List LastRunTime,LastTaskResult,NextRunTime
# Solo cuando quieras ensayar deliberadamente una ejecución:
# Start-ScheduledTask -TaskName $TaskName
# Para detener futuras activaciones de la tarea de curso:
# Disable-ScheduledTask -TaskName $TaskName
# Para retirarla, revisa el nombre y ejecuta de forma interactiva:
# Unregister-ScheduledTask -TaskName $TaskName
