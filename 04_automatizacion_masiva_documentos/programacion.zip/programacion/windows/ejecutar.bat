@echo off
setlocal
for %%I in ("%~dp0..\..") do set "PROJECT_DIR=%%~fI"
set "PYTHON_EXE=%PROJECT_DIR%\.venv\Scripts\python.exe"
set "CONFIG_FILE=%PROJECT_DIR%\trabajo_demo\config.json"
if not exist "%PYTHON_EXE%" exit /b 20
if not exist "%CONFIG_FILE%" exit /b 20
if not exist "%PROJECT_DIR%\logs" mkdir "%PROJECT_DIR%\logs"
if not exist "%PROJECT_DIR%\logs" exit /b 20
cd /d "%PROJECT_DIR%"
if errorlevel 1 exit /b 20
"%PYTHON_EXE%" -u "%PROJECT_DIR%\procesar_lote.py" --config "%CONFIG_FILE%" >> "%PROJECT_DIR%\logs\lote.stdout.log" 2>> "%PROJECT_DIR%\logs\lote.stderr.log"
set "RESULTADO=%ERRORLEVEL%"
exit /b %RESULTADO%
