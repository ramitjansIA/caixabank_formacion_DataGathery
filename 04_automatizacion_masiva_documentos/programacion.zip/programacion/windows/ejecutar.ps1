﻿param([switch]$Simular)
$ErrorActionPreference = 'Stop'
try {
    $ProjectDir = Split-Path -Parent (Split-Path -Parent $PSScriptRoot)
    $PythonExe = Join-Path $ProjectDir '.venv\Scripts\python.exe'
    $ScriptFile = Join-Path $ProjectDir 'procesar_lote.py'
    $ConfigFile = Join-Path $ProjectDir 'trabajo_demo\config.json'
    if (-not (Test-Path -LiteralPath $PythonExe -PathType Leaf)) { throw 'Falta el Python del entorno virtual' }
    if (-not (Test-Path -LiteralPath $ConfigFile -PathType Leaf)) { throw 'Crea primero trabajo_demo' }
    $LogDir = Join-Path $ProjectDir 'logs'
    New-Item -ItemType Directory -Path $LogDir -Force | Out-Null
    $RunId = [guid]::NewGuid().ToString('N')
    $OutLog = Join-Path $LogDir ($RunId + '.stdout.log')
    $ErrLog = Join-Path $LogDir ($RunId + '.stderr.log')
    # Start-Process une ArgumentList: se conservan comillas alrededor de rutas.
    $PythonArgs = @('-u', ('"{0}"' -f $ScriptFile), '--config', ('"{0}"' -f $ConfigFile))
    if ($Simular) { $PythonArgs += '--simular' }
    $Child = Start-Process -FilePath $PythonExe -ArgumentList $PythonArgs `
        -WorkingDirectory $ProjectDir -Wait -PassThru -NoNewWindow `
        -RedirectStandardOutput $OutLog -RedirectStandardError $ErrLog
    exit $Child.ExitCode
} catch {
    [Console]::Error.WriteLine($_.Exception.Message)
    exit 20
}
