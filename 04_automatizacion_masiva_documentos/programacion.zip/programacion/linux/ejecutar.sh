#!/bin/sh
# POSIX: invocable desde cron. No instala tareas.
set -u
PROJECT_DIR=$(CDPATH= cd -- "$(dirname -- "$0")/../.." && pwd) || exit 20
PYTHON_EXE="$PROJECT_DIR/.venv/bin/python"
CONFIG_FILE="$PROJECT_DIR/trabajo_demo/config.json"
[ -x "$PYTHON_EXE" ] || exit 20
[ -f "$CONFIG_FILE" ] || exit 20
mkdir -p "$PROJECT_DIR/logs" || exit 20
cd "$PROJECT_DIR" || exit 20
"$PYTHON_EXE" -u "$PROJECT_DIR/procesar_lote.py" --config "$CONFIG_FILE" >> "$PROJECT_DIR/logs/lote.stdout.log" 2>> "$PROJECT_DIR/logs/lote.stderr.log"
RESULTADO=$?
exit "$RESULTADO"
